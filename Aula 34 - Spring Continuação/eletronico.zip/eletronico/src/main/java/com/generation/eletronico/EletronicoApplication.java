package com.generation.eletronico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EletronicoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EletronicoApplication.class, args);
	}

}
